DC MOTRIX — Prototipo web inicial
================================
Abrir index.html en un navegador.

Incluye páginas: Inicio, Quiénes somos, Servicios, Tarifas, Promociones, FAQ, Contacto, Citas, Cotizaciones, Privacidad, Términos y Panel administrativo (demostrativo).

IMPORTANTE:
- Es un prototipo frontend estático. No tiene backend, base de datos, login real, envío de formularios, calendario operativo, notificaciones WhatsApp, PDFs, almacenamiento seguro de fotos ni copias automáticas reales.
- No usar admin.html para datos reales ni publicar el sitio como sistema operativo.
- El emblema “DC” es un marcador temporal. Sustituirlo por el archivo original del logo de DC MOTRIX sin modificarlo.
- Los textos legales son borradores y deben ser revisados y completados antes de publicar.
- La opción elegida para fotos queda resuelta por defecto como ambas: organización por orden de trabajo y consulta centralizada por cliente/vehículo.
- Las solicitudes deben requerir confirmación manual del taller.
